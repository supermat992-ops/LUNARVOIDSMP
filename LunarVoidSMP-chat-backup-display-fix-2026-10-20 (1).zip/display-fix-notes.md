# Display corrections — 2026-10-20

Use **lunarvoidsmp-0.6.2-test-display-fix.jar**. This supersedes the earlier all-bans JAR and retains its ban handling, pricing table, payment confirmation and other prior changes. The internal version is still 0.6.2-test; no dependency or version change in this correction.

## Changes

- Inventory sell-price tooltips now work in Creative as well as Survival when **Settings → Item Price is ON**. Existing saved preferences remain; new players still start OFF.
- Closing Settings now refreshes the actual player inventory on the next tick, so ON/OFF updates are not stranded in a menu. Creative clones are cleaned before reaching the server, including temporary lines returned as legacy text without the marker. Real item values and auction/listing rules are unchanged.
- Sidebar lines use one text representation. This removes the duplicated labels/values seen in the screenshots. Modern clients receive complete text/components, preserving full usernames, Discord invite and per-character animation colors. Old clients before1.13 retain their bounded team fields. TPS displays20 rather than20.0 when exact. Per-player settings still control the same lines and rank visibility.
- Main `/shop` slots51 and52 are empty: no Your Items chest and no Back to Shop ender chest there. Auction and Your Items navigation remains available in those screens.
- Sign input was deferred by the user and is unchanged.

## Installation

Stop the server, back up its player/plugin/economy data and replace the older Lunar JAR; keep only one Lunar JAR installed. Keep standalone TAB disabled/removed. Keep ViaVersion, ViaBackwards, ViaRewind, PlaceholderAPI, LuckPerms, Vault and a compatible economy provider. Enable Item Price in Settings to show the hover line.

## Verification

- Fresh clean verify: **134 tests passed**, zero failures/errors/skips.
- Live Java1.21.4 and Via1.8.9 checks passed for menu button locations, Survival/Creative prices, ON/OFF refresh, clean Creative cloning and saved preference on rejoin.
- Captured score/team packets verified full Player/Money/Discord/TPS text once each, with no custom score name. Modern animation components/templates remain intact; old-client field limits are preserved.
- Saved original and Creative-cloned stacks both remain plain64dirt, with no item metadata or price lore.
- JAR integrity/resources/Java25/internal metadata/SQLite/privateNBT checks and git diff --check passed.
- Previous nine all-ban live checks are reused for unchanged ban code; the full automated suite was rerun here.

**Quest display is still unverified.** Geyser2.12.0b1265 started and native UDP ping succeeded, but its Bedrock login rejected the synthetic unsigned account with an Xbox-login requirement. No gameplay/rendering compatibility claim follows from that connection. A real signed-in Quest/Bedrock check remains necessary. EssentialsX2.22.0 also reports the existing unsupported-Paper-version warning.

Other earlier limits remain: native automatic cheating bans are OFF pending calibration; private/proxy bans without a Paper signal need the documented hook; no duels. No commit, push or remote publication.

## Files changed in this correction

Menus.java; OwnTab.java; InventoryPriceDisplay.java; PacketPriceTooltip.java; ItemPriceTooltip.java; OwnTabLineTest.java; PacketPriceTooltipTest.java; docs/ITEM_PRICES.md; docs/TESTING.md.

## Artifact

SHA256: `0be3aa2024a0b02eb60bed9bf41aa0cd4e012594e38d12c58cd9b5f9f3aaf495`
Size: 19637336 bytes.
