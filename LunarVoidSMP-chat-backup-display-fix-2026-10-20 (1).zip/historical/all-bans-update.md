# All-ban inventory penalty — 2026-10-20

This update supersedes the earlier Lunar-only scope. Use `lunarvoidsmp-0.6.2-test-all-bans.jar`; the internal version remains **0.6.2-test**. No dependency/version/workflow changes.

## Install

Stop the server and back up player/plugin/economy data. Replace the older Lunar JAR, keeping only one Lunar JAR installed. Disable/remove standalone TAB to activate Lunar's built-in display. Keep third-party ViaVersion, ViaBackwards and ViaRewind, plus PlaceholderAPI/LuckPerms/Vault and a compatible economy provider.

## Coverage

**All ban reasons**, permanent or temporary, use the same item penalty: carried inventory, armor, offhand and remaining cursor items drop at the player's location; ender chest contents are deleted, not dropped. XP, money and items held in auction/claim storage are unaffected.

Automatically observed:

- Lunar bans, as before.
- Standard Paper player/profile and IP ban lists, including vanilla and plugins using those lists. Scan once per second, ignore expired entries, persist deduplication across restarts. Active external entries present at startup are observed too.
- Uncancelled Paper kicks marked BANNED/IP_BANNED, or kicks linked to a standard ban entry.
- Final Paper pre-login/login denials marked KICK_BANNED.

Offline players queue item loss until their next admitted join after unban/expiry. IP bans map UUIDs using addresses observed by this version; unknown accounts need a subsequent rejected login or explicit UUID hook. Last observed addresses are saved in anticheat.db. Ordinary/traffic kicks do not cause loss, even if their message says "banned". A cancelled ban-kick event alone does not cause loss; an actual active list entry is still covered. External bans never add Lunar cheating strikes or change another provider's ban duration.

### Private/proxy systems require integration

If a provider exposes no Paper ban event/list, configure it to call the console/authenticated-RCON hook after committing its ban:

`lunarac externalban <online-name-or-uuid> <unique-ban-id>`

Use one stable ID per punishment and UUID for offline targets. Repeating that ID does not repeat completed item loss. The hook applies/queues item loss; it does not issue/extend a ban. Players and command blocks cannot invoke it. A private/proxy ban with no signal/hook cannot be automatically observed. A very short list-only ban created and removed entirely between scanner ticks also needs the hook for guaranteed notification. No provider credentials or real remote ban systems were used in testing.

## Verification

- Fresh Java25/Maven3.9 clean verify: **130 tests, zero failures/errors/skips**. New tests cover all kick-cause classifications, ban expiry, millisecond-distinct identities, console/RCON/player/block trust boundaries, persistent deduplication, later episodes, rollback, IP address mapping and isolation from Lunar strikes.
- Live Paper26.3 build205 with ViaVersion/ViaBackwards5.12.1, ViaRewind4.2.0, Vault1.7.3, EssentialsX2.22.0, LuckPerms5.5.87 and PAPI2.12.3. Nine staged checks passed: ordinary kick containing banned text, cancelled typed ban, typed third-party Paper ban, vanilla manual ban, Essentials manual ban, offline profile scanner, offline IP scanner, private-provider rejected login and explicit private-provider hook.
- Every positive item-loss stage dropped exactly gold5, iron helmet1 and torch3, deleted ender diamonds4, and saved empty inventory/ender chest. Negative kick stages preserved items. Synthetic BanProbe was only a local fixture, not shipped.
- Prior unchanged item mutation/rejoin/duplicate and menu/payment/tooltip/sidebar checks are reused where equivalent. Fresh suite covers their automated regressions. No new full gameplay/Bedrock/load/Discord verification.
- Archive integrity, new listener/queue classes, internal version, Java25 bytecode, private PacketEvents/AdventureNBT/public API references and SQLite libraries passed inspection. No BanProbe included. git diff --check passed.

## Remaining limits

Automatic native cheating bans remain **OFF** pending real-player calibration. Native checks do not detect every listed hack. EssentialsX2.22.0 warns this Paper version is unsupported. Actual production dependency compatibility, arbitrary Via movement/gameplay, Bedrock/Quest rendering/input, load and real Discord delivery remain unverified.

Player/world/SQLite saves are not atomic. Failed/interrupted item mutations remain REVIEW and are not automatically replayed; a crash can lose unsaved world drops. Cancelled item spawns retain definitely undropped items for staff review. Actual third-party/private/proxy integrations need checking with their installed versions. See docs/ANTI_CHEAT.md for precise coverage and recovery limits. No duels work.

## Files changed this turn

- New ExternalBanItems.java and ExternalBanItemsTest.java.
- AntiCheatService.java: observer lifecycle, integration hook, authenticated RCON gate.
- anticheat/CheatingBans.java and CheatingBansTest.java: external observations, once-only queue, address mapping and tests.
- README.md and docs/ANTI_CHEAT.md: expanded scope/integration/limits.

All task edits remain uncommitted; no push or remote publication.

## Artifact

SHA256: `563e379b24a9cabe68934df155f0d6866e4168bb5c242d1eed6d8f8be61be99c`
Size: 19636452 bytes.
