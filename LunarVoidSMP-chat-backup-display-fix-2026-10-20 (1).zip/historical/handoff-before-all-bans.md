# LunarVoidSMP chat handoff — 2026-10-20

## Active user instructions

- Do not paste source code into chat. JAR creation is explicitly authorized. No remote publication/commit/push requested.
- Preserve existing listing and auction purchase confirmations and economy safety. Only change other GUI details when specifically requested.
- No duels yet: user wants to finish/test the core first, then begin duels later.
- ViaVersion, ViaBackwards and ViaRewind are THIRD-PARTY plugins installed separately for older Minecraft clients. Do not bundle or replace them.
- Lunar owns the new animated scoreboard/tab display; disable/remove standalone TAB to activate it. Keep PlaceholderAPI and LuckPerms.
- Latest request: new bans drop carried inventory and delete ender chest contents, rebuild JAR and back up this chat. Implemented for Lunar cheating bans. Optional question about also applying to third-party/manual bans was unanswered at packaging time; do not claim all external bans are covered.

## Implemented requirements and retained decisions

- AH/Your Items/Pay screenshot layouts, only populated pages, page cap100,000,000, screenshot navigation, oxidized copper Settings icon, own Money head with green$ and abbreviated balance. Existing listing/purchase flow retained. Pay requires amount then Confirm payment; only Confirm sends. Green-dollar abbreviated notifications.
- Built-in title/divider/Discord animations; invite discord.gg/ZtpFbjCSU. Per-viewer Rank defaults BothOFF and cycles NamesON → SidebarON → BothON → BothOFF. Separate persisted preferences, PAPI/LuckPerms rank integration and individual sidebar visibility controls. Legacy client text fallback simplifies crowded colors and obeys old length limits. Exact old-client visual parity is unverified.
- Fixed rarity prices for all1657non-air pinned registry item materials, dirt$2/ancientdebris$1M, unit cap$1B. Item Price tooltip defaultsOFF; packet-only, no mutation of real item lore. Preserve custom/disabled prices. Modified/damaged/enchanted special-item eligibility restrictions remain.
- Native coarse movement/ascent/hover/reach safeguards; action/chat/packet limits. NO Grim or external anti-cheat required. No visual-mod detector; not all requested combat/movement/world/inventory hacks have dedicated detection. Native automatic bans remainOFF pending calibration; corrections and invalid-hit blocking enabled.
- Separate anticheat.db:24h→3d→1w→2w→3w→4w capped; supplied ban screen and appeal https://discord.gg/HAYPe9VtV. Private configurable Discord webhook, no real URL configured/tested.
- New inventory penalty queues with ban transaction, drops real carried inventory including armor/offhand/cursor, deletes ender chest. Offline waits until next admittedjoin; old/external bans/ordinary kicks excluded. Duplicate callbacks do not repeat. Interrupted actions enterREVIEW and do not auto-replay; history shows state. Player/world/SQLite saves are not atomic; abrupt crashes can lose unsaved drops.

## Current files and build

Actual source: /home/vercel-sandbox/workspace/repos/github.com/superninja7667-byte/lunarvoidsmp-plugin
Git baseline984891c78a556ee5c23a9caae3d2e24380f3aaf6; task changes uncommitted. Connected LunarVoidSMP checkout is README-only.
Internal version remains0.6.2-test. Original renamed0.6.3 filename did not change its internal version. No version/dependency/workflow changes in this turn. Earlier packaging repair privately bundles AdventureNBT5.2.0 and preserves public nbt.api references.
Build: mise exec java@temurin-25 maven@3.9 -- mvn -B -ntp clean verify
Latest build121 tests,zero failures/errors/skips. Source change files this turn: AntiCheatService.java, newBanInventoryPenalty.java, anticheat/CheatingBans.java, anticheat/CheatingBansTest.java, README.md, docs/ANTI_CHEAT.md.
JAR: lunarvoidsmp-0.6.2-test-ban-items.jar
SHA256e511202ccdd8a454cfbe704639b1c5aae8d7284609adb88b4cff29084b615bb1

## Verification and limits

This turn:121automated tests; real Paper26.3build205 online drops dirt2+ironhelmet1+torch3, no enderdiamond drops, saved inventoriesempty, duplicate strike1/DONE, unbanrejoinempty. Offline savedgold5/enderdiamond4→queuedban→unbanjoin→onegold5entity+saved/clientempty/DONE. Fixture errors (initial spawn timeout, historical data path and duplicate metadata events) were corrected without plugin workarounds.
Earlier unchanged payment/menu/tooltip/scoreboard tests remain valid: menus with Java1.8.9/1.12.2;1.21.4 GUI-only harness suppresses invalid periodic botmovement. Payment close-no-charge/confirmed exactly$1000 journal/balances/notification, rankcycle and legacy fullinvite text passed. These are not gameplay proof.
Runtime fixture plugins: ViaVersion/ViaBackwards5.12.1, ViaRewind4.2.0, Vault1.7.3, EssentialsX2.22.0, LuckPerms5.5.87, PAPI2.12.3. Essentials warns Paper version unsupported. Older full Essentials2.21.2/PAPI2.11.6 failed parsing this Paper version. Do not equate provided Maven APIs with supported production plugin binaries.
Unverified: real movement/combat calibration, arbitrary Via/client versions, production economy, Geyser/Quest visuals/input,2.5GB/load, real Discord, arbitrary crashes/third-party item-spawn cancellation. No universal hack detection/all-settings readiness claim.
Detailed working validation record is workspace-context/validation-record.md; reproducible task input hashes workspace-context/lunar-ban-items-inputs.sha256. Temporary local server/bots under/tmp; disposable offline synthetic fixture was loopback-only. Do not treat that config as production guidance.

## Backup contents

Stored user/assistant conversation export (all34messages available through capture, one long pasted message reassembled), original17attachments, this handoff and delivery notes. Internal tool logs/UIquestion cards and future messages after capture are not exported. This is a chat/reference backup, not a production server/database backup.
