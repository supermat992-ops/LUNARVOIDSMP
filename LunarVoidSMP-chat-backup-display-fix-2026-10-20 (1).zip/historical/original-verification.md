# LunarVoidSMP test JAR — 2026-10-20

Internal version: **0.6.2-test**, kept as requested in the handoff. Filename renaming does not change it. Baseline commit: `984891c78a556ee5c23a9caae3d2e24380f3aaf6`; task changes are uncommitted. No remote publication performed.

## Included

- AH/Your Items/Pay layouts and navigation; only populated pages, maximum 100,000,000. Pay amount input opens **Confirm payment**; transfer occurs only after Confirm. Existing listing and auction purchase flows retained. Money heads, oxidized copper settings icons and abbreviated green-dollar payment/sale notices.
- Animated built-in sidebar, PlaceholderAPI/LuckPerms integration, personal Rank cycle (Both OFF → name tags ON → scoreboard ON → Both ON → Both OFF), saved independently per viewer. Individual sidebar/Discord visibility controls. Older clients receive bounded legacy team text, simplifying crowded animation colors to keep the invite readable; modern clients retain full colored text. Discord animation uses `discord.gg/ZtpFbjCSU`.
- Fixed rarity prices for all 1,657 non-air registry item types. Dirt$2, ancient debris$1M; unit cap$1B. Inventory Item Price toggle defaults OFF, applies packet-only tooltips and leaves real item lore unchanged.
- Native coarse speed/ascent/hover/reach safeguards, action/packet/chat traffic limits, persistent cheating ban ladder24h→3d→1w→2w→3w→4w, private Discord webhook support. No Grim dependency.
- Packaging repair for PacketEvents AdventureNBT; Paper's public NBT API remains unrelocated.

## Install on a test server

1. Stop the server and back up plugin data, inventories and economy. Replace the old Lunar JAR; keep only one Lunar plugin JAR.
2. Use Java25 and a compatible Paper server. Keep Vault and a supported economy provider; keep PlaceholderAPI/LuckPerms for integrations and the Via plugins needed by your clients. **Remove or disable standalone TAB to activate Lunar's built-in replacement.**
3. Start and inspect Lunar status and logs. Saved preferences and custom/disabled prices are retained; bundled old defaults migrate. Rank and inventory Item Price start OFF for new players.
4. Configure your private Discord URL in `plugins/LunarVoidSMP/anticheat.yml`, then run `lunarac reload` in console. Do not share the URL.
5. **Native automatic bans are OFF by default.** Corrections, invalid-hit cancellation and alerts remain on. Calibrate with legitimate players before enabling automatic bans.

## Observed verification

- Final `mvn -B -ntp clean verify` under Temurin25.0.4.1/Maven3.9.16: **117 tests, no failures/errors/skips**, shaded package produced.
- Actual isolated Paper26.3 build205 startup with Vault1.7.3, EssentialsX2.22.0, LuckPerms5.5.87, PlaceholderAPI2.12.3, ViaVersion5.12.1, ViaBackwards5.12.1 and ViaRewind4.2.0. PAPI Lunar/Formatter expansion and Vault economy hook worked.
- Java1.8.9 and1.12.2 bot clients opened Shop, Settings, AH, Your Items and Pay. Java1.21.4 opened all five in a GUI-only harness. Its ordinary periodic bot movement was rejected by the server, so periodic movement was suppressed for GUI checks; this is **not** gameplay compatibility verification.
- Payment: closing confirmation left balances10000/0 and no trade; one confirmed payment produced9000/1000 and exactly one  completed$1000 journal entry. Both notification messages showed$1.0K. Operator client could not call console punishment command.
- All four Rank states persisted through the live GUI cycle; inventory dirt2 showed sell value$4.00 through ViaRewind.
- Console punishment kicked the synthetic online player, blocked rejoin with supplied appeal message, did not escalate on duplicate, and increased24h to3d after unban/repeat. Unit tests cover expiry, atomic storage, duplicate/concurrent calls and full ladder cap.
- Final live sidebar packets verified the old client receives Player name, $9.0K balance and the full correct Discord invite; modern custom display names remain present.
- Archive integrity, internal metadata, Java25 bytecode, resources, SQLite driver/native library, private PacketEvents/NBT and retained public API references checked. All 20 Discord frames verified.

## Limits and remaining checks

- This is a development test build. Native checks do **not** detect every listed hack. There are no dedicated aim/killaura/anti-knockback/NoFall/mining/build/inventory-automation detectors or visual-mod detection. See repository `docs/ANTI_CHEAT.md` for exact coverage.
- EssentialsX2.22.0 hooks Vault here but reports this Paper version unsupported. The older full EssentialsX2.21.2 and PAPI2.11.6 runtime plugins failed version parsing. Use versions supported by your actual server; the Maven provided API versions were preserved.
- Real-player movement/combat calibration, arbitrary Via versions, Geyser/Quest visuals/clicks/sign input, production economy provider, full pages under load,2.5GB performance and real Discord delivery are unverified. No real webhook was used. Old client length/color limits can shorten sidebar lines and title; exact visual parity is unverified.
- Existing unrelated unavailable settings remain outside this patch; the historical project status describes those gaps. This is not a claim every setting or every gameplay feature has passed a live test.
- **Duels has not been started.**

## Changed source files

- README.md
- docs/ANTI_CHEAT.md
- docs/ITEM_PRICES.md
- docs/STATUS.md
- docs/TESTING.md
- pom.xml
- src/main/java/gg/lunarvoidsmp/AntiCheatService.java
- src/main/java/gg/lunarvoidsmp/InventoryPriceDisplay.java
- src/main/java/gg/lunarvoidsmp/ItemPriceTooltip.java
- src/main/java/gg/lunarvoidsmp/LegacySidebarLine.java
- src/main/java/gg/lunarvoidsmp/LunarPlugin.java
- src/main/java/gg/lunarvoidsmp/Menus.java
- src/main/java/gg/lunarvoidsmp/NativeAntiCheat.java
- src/main/java/gg/lunarvoidsmp/OwnTab.java
- src/main/java/gg/lunarvoidsmp/PacketDisplays.java
- src/main/java/gg/lunarvoidsmp/PacketFloodGuard.java
- src/main/java/gg/lunarvoidsmp/PacketPriceTooltip.java
- src/main/java/gg/lunarvoidsmp/Preferences.java
- src/main/java/gg/lunarvoidsmp/Prices.java
- src/main/java/gg/lunarvoidsmp/SellPriceDefaults.java
- src/main/java/gg/lunarvoidsmp/anticheat/BanText.java
- src/main/java/gg/lunarvoidsmp/anticheat/CheatingBans.java
- src/main/java/gg/lunarvoidsmp/anticheat/DiscordAlerts.java
- src/main/java/gg/lunarvoidsmp/anticheat/MotionWindow.java
- src/main/java/gg/lunarvoidsmp/anticheat/TrafficBudget.java
- src/main/java/gg/lunarvoidsmp/core/MenuPage.java
- src/main/java/gg/lunarvoidsmp/core/RankVisibility.java
- src/main/java/gg/lunarvoidsmp/core/SellValue.java
- src/main/java/gg/lunarvoidsmp/core/Store.java
- src/main/resources/anticheat.yml
- src/main/resources/config.yml
- src/main/resources/plugin.yml
- src/main/resources/sell-prices.yml
- src/main/resources/tab-animations.yml
- src/test/java/gg/lunarvoidsmp/LegacySidebarLineTest.java
- src/test/java/gg/lunarvoidsmp/NativeAntiCheatSettingsTest.java
- src/test/java/gg/lunarvoidsmp/PacketPriceTooltipTest.java
- src/test/java/gg/lunarvoidsmp/PacketTestSupport.java
- src/test/java/gg/lunarvoidsmp/PriceTableTest.java
- src/test/java/gg/lunarvoidsmp/RankVisibilityTest.java
- src/test/java/gg/lunarvoidsmp/SellPriceDefaultsTest.java
- src/test/java/gg/lunarvoidsmp/anticheat/CheatingBansTest.java
- src/test/java/gg/lunarvoidsmp/anticheat/DiscordAlertsTest.java
- src/test/java/gg/lunarvoidsmp/anticheat/MotionWindowTest.java
- src/test/java/gg/lunarvoidsmp/anticheat/TrafficBudgetTest.java
- src/test/java/gg/lunarvoidsmp/core/MenuPageTest.java
- src/test/java/gg/lunarvoidsmp/core/SellValueTest.java

## Artifact

SHA256: `45a576139becc677ee4ac9d092df4ca92685646c8c42dc450dffc7e1336b2aac`
Size: 19627646 bytes.
