# Ban inventory update — 2026-10-20

## Install

Stop the server, back up plugin/player/economy data and replace the old Lunar JAR. Keep only one Lunar JAR installed. The filename has `ban-items` to distinguish this download; its internal version remains **0.6.2-test**, as required by the handoff. No dependencies/version/workflow changed in this update.

**Disable or remove the separate TAB plugin** to use Lunar's built-in scoreboard/tab display. Keep third-party ViaVersion, ViaBackwards and ViaRewind; these provide older-client compatibility and are not part of Lunar. Keep PlaceholderAPI, LuckPerms, Vault and a compatible economy provider.

## New behavior

A **new Lunar cheating ban** drops the player's carried inventory at their location before kicking them. Armor, offhand and remaining cursor items are included. Ender chest contents are deleted, not dropped. Open menus close first, returning crafting/Sell items before the inventory snapshot. XP, money and items still held in auction/claim storage are unaffected.

For an offline UUID, the penalty is saved and runs on the next admitted join after expiry/unban, at that join location. It does not alter offline NBT or drop items while the player is absent. Other plugins' bans, old bans and ordinary kicks do not trigger it. The question about also covering manual/third-party bans was unanswered when this build was prepared; this build covers Lunar cheating bans.

Duplicates do not repeat completed item penalties. `lunarac history` includes their state. A failure/crash during mutation remains REVIEW and is not automatically replayed, including on a later ban, to avoid duplicate drops. If a third-party spawn event cancels a drop, definitely undropped items are retained for staff review while the ban still applies. Player saves, world saves and SQLite are not atomic: an abrupt crash can lose unsaved world drops.

**Automatic native cheating bans remain OFF by default**, pending real-player calibration. Console Lunar bans still work. This update does not extend detector coverage.

## Validation

- Java Temurin25.0.4.1/Maven3.9.16: clean verify passed **121 tests**, zero failures/errors/skips. New SQLite checks cover persistent once-only application, duplicates/restarts, old-ban upgrade, offline/unban retention and queue transaction rollback.
- Isolated Paper26.3 build205 with ViaVersion/ViaBackwards5.12.1, ViaRewind4.2.0, Vault1.7.3, EssentialsX2.22.0, LuckPerms5.5.87 and PAPI2.12.3. Online ban dropped exactly dirt2, iron helmet1 and torch3; no ender diamonds dropped. Saved inventory and ender chest were empty. Duplicate left strike1/penaltyDONE. Unban/rejoin did not restore items.
- Offline flow passed: saved gold5/ender diamonds4 before disconnect; offline ban queued PENDING; unban/join dropped exactly one gold5 entity, cleared both saved inventories and showed empty client inventory; queue finished DONE. Observer metadata updates were deduplicated by entity ID.
- Archive integrity, internal metadata, private PacketEvents/AdventureNBT packaging, Java25 class version and SQLite libraries passed inspection. git diff --check passed.
- Prior unchanged menus/payment/tooltip/scoreboard checks from the earlier delivery remain valid for those inputs; not all were rerun this turn.

This is still a **test build**: Essentials2.22.0 warns this Paper version is unsupported. Real gameplay/Via movement, production dependency support, Bedrock/Quest visuals, load and real Discord delivery remain unverified. No duels work was started. See the earlier verification report for the broader build limits.

## Files changed in this update

- AntiCheatService.java — apply penalty before Lunar ban kicks, process pending penalties early on join/reload, report status.
- BanInventoryPenalty.java (new) — actual inventory/ender chest/world changes and player save.
- anticheat/CheatingBans.java — atomic penalty queue, once-only reservation/completion.
- anticheat/CheatingBansTest.java — four regression tests.
- README.md and docs/ANTI_CHEAT.md — behavior, external Via/TAB distinction and persistence limits.

No commit, push or remote publication performed.

## Artifact

SHA256: `e511202ccdd8a454cfbe704639b1c5aae8d7284609adb88b4cff29084b615bb1`
Size: 19629988 bytes.
