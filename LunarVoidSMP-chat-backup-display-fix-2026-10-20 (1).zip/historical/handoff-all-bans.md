# Current handoff — all-ban scope, 2026-10-20

## Latest user instruction and status

The user clarified: losing items applies to every ban reason/provider, not only Lunar cheating bans. This clarification supersedes the earlier unanswered optional question and all historical Lunar-only scope notes. They asked for a chat backup within19minutes; this archive preserves the latest instruction, references and current delivery notes. Implementation, build and live validation are complete for the observable/integrated ban paths described below.

Do not paste source code into chat. JAR delivery is authorized. Do not start duels yet. Keep third-party ViaVersion/ViaBackwards/ViaRewind. Disable/remove standalone TAB to use Lunar's replacement; keep PlaceholderAPI/LuckPerms/Vault/economy dependencies. Preserve earlier GUI/pricing/transaction requirements from the conversation and historical handoff.

## Current delivery and source

Current JAR: lunarvoidsmp-0.6.2-test-all-bans.jar
Internal version0.6.2-test; no version/dependency/workflow changes this turn. SHA256563e379b24a9cabe68934df155f0d6866e4168bb5c242d1eed6d8f8be61be99c.
Actual source: /home/vercel-sandbox/workspace/repos/github.com/superninja7667-byte/lunarvoidsmp-plugin
Baseline984891c78a556ee5c23a9caae3d2e24380f3aaf6 plus uncommitted task changes. The connected LunarVoidSMP repo is README-only. No commit/push/remote publication occurred. This is a chat/reference backup, not a source-code or production-server/database backup. The current JAR is a separate download.
Build: mise exec java@temurin-25 maven@3.9 -- mvn -B -ntp clean verify
130tests passed,0failures/errors/skips. Nine real Paper fixture stages passed; see all-bans-update.md.
Validation working record and final input hashes are included. Historical handoff/report files describe prior stages and must not override current scope, artifacts or counts.

## Coverage boundary requiring attention

All ban reasons are eligible. Standard profile/IP lists and actual Paper ban kick/login signals are observed automatically. A private/proxy provider exposing no Paper signal must call the console/RCON externalban hook with a stable per-ban ID. Do not claim automatic universal discovery of private provider databases. Offline penalties wait for the next admittedjoin; IP identities require an observed address, rejected login or explicit UUID hook.
Native automatic cheating bans remainOFF until calibrated. The new observer does not add cheating strikes or change external ban lengths. Ordinary kicks are excluded. Crash/third-party cancellation and production version limits remain as documented.

## Local fixture lifecycle

Loopback Paper26.3build205 used the existing Via/Vault/Essentials/LuckPerms/PAPI fixture plus a disposable synthetic BanProbe. The fixture stopped cleanly after tests, forceload removed, RCON disabled/password removed and BanProbe JAR removed. None is bundled with the plugin. Recreating advanced runtime tests requires re-preparing their private local RCON/probe fixture; do not expose offline-mode test config publicly.

## Backup contents

All36stored user/assistant messages available through capture (the long pasted message reassembled), current and historical handoffs, current and historical delivery notes, validation/input identity records and17original attachments. Internal tool logs/UIquestion cards, source files and future messages after capture are excluded.
